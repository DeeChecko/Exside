﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlayerMovement_Test
{
    
    public class PlayerMove_test : MonoBehaviour
    {
        public GameObject clone; // clone of the ship
        public GameObject Bolt; // prefab bolt 
        public Transform Position;
        public Rigidbody2D rd;
        public float push = 20; // the speed of the player
        private float Left_Side = -14; // this is the x value for the left side of the game 
        private float Right_Side = 14; // this is the x value for the right side of the game 
        private float y = -6; // this is the y postion for the ship
       
        // Use this for initialization
        void Start()
        {
            rd = this.gameObject.GetComponent<Rigidbody2D>();
        }
        //updates each frame
        void Update()
        {
            if (Input.GetKey(KeyCode.A))//Input "A" to move left
            {
                rd.AddForce(Vector2.left * push);
                //Debug.Log("A was pressed");// Debug 0
            }
            if(Input.GetKey(KeyCode.D)) //Input check to move Right 
            {
                rd.AddForce(Vector2.right * push);
                //Debug.Log("D was presed ");// Debug 1
            }
            if (Input.GetKey(KeyCode.Space)) // Input check "space" to fire weapon
            {
                //Debug.Log(Position);// Debug 2
                Instantiate(Bolt);
            }
        }
        private void OnCollisionEnter2D(Collision2D coll)
        {
            if (coll.gameObject.tag == "Wall Left") ; //if hit Wall Left
            {
                Debug.Log("hit left wall");
            }
            if (coll.gameObject.tag == "Wall Right") ; // if hit wall Right 
            {
                Debug.Log("hit right wall");
                //Instantiate(clone, )
            }
            if (coll.gameObject.tag == "Baddie") ;
            {
                Destroy(this.gameObject);
            }
        }
    }
}