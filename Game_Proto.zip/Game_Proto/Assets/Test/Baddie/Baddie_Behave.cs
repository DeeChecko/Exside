﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Baddie_Behave : MonoBehaviour {

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Bolt"); // if this collids with the player bolt this kills itself
        {
            //Instantiate(Resources.Load(Baddie));
            Debug.Log("hit");
            Destroy(this.gameObject); // destroys this game object
        }
        if (coll.gameObject.tag == "City") ;
        {
            Destroy(this.gameObject); // destroys this game object
            //Instantiate(Resources.Load(Baddie));
        }
    }
}