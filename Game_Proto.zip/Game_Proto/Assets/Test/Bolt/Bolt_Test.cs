﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bolt_Test : MonoBehaviour
{

    public float push = 1000;
    public Transform hold;
    private Rigidbody2D rd;
    // Use this for initialization
    void Start()
    {
        rd = this.gameObject.GetComponent<Rigidbody2D>();
        rd.AddForce(Vector2.up * push);

    }

    //updates each frame
    void Update()
    {
    }
    private void OnCollisionEnter2D(Collision2D coll)
    {
        
        if (coll.gameObject.tag == "Wall Top")
        {
            Debug.Log("Hit Wall"); //debug 0
            Destroy(this.gameObject);
        }
        if(coll.gameObject.tag == "Baddie")
        {
            Debug.Log("Hit Baddie"); //debug 1
            Destroy(this.gameObject);
        }
    }
}